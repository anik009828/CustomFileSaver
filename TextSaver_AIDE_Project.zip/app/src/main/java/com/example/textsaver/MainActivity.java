package com.example.textsaver;

import android.os.Bundle;
import android.os.Environment;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        EditText text=findViewById(R.id.editText);
        EditText name=findViewById(R.id.fileName);
        Button btn=findViewById(R.id.saveBtn);

        btn.setOnClickListener(v->{
            try {
                File dir=new File(Environment.getExternalStorageDirectory(),"textdata");
                if(!dir.exists()) dir.mkdir();
                File f=new File(dir,name.getText().toString());
                FileOutputStream fos=new FileOutputStream(f);
                fos.write(text.getText().toString().getBytes());
                fos.close();
                Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();
            }catch(Exception e){
                Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}
